public class DiaryEntry {
    int date;
    String entryText;
    String mood;

    void text(String entringText) {
        entryText = entringText;
        System.out.println(entringText);

    }

    void display(int date, String mood) {
        System.out.println("Date " + date + " mood" + mood);
    }
}
