import java.time.DateTimeException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int d = 0;
        try {
            Scanner sc = new Scanner(System.in);
            int date = sc.nextInt();

            if (date > 31) {
                throw new DateTimeException("Invalid date");

            } else {
                d = date;
                DiaryEntry de = new DiaryEntry();
                de.display(21, "a1b2");
                de.text("abcd");
            }
        } catch (DateTimeException e) {
            System.out.println("invalid entry");
        } catch (Exception e) {
            System.out.println("Enter date format");
        }
    }
    }
