import java.util.Scanner;

public class Main {

        public static void main(String[] args) {
            System.out.println("Enter  your choice " + "choice 1 for Creditcardpayment" + "choice 2 for Paypalpayment");
            Scanner sc = new Scanner(System.in);
            int choice = sc.nextInt();
            if (choice == 1) {
                CreditCardPayment cc = new CreditCardPayment();
                cc.processPayment();
                cc.generatePayment();

            } else if (choice == 2) {
                PayPalPayment cc = new PayPalPayment();
                cc.processPayment();
                cc.generatePayment();

            } else {
                System.out.println("Invalid Entry");
            }
        }

    }
