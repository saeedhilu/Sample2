

    public interface payment {

        void processPayment();

        void generatePayment();
    }

    class CreditCardPayment {

    } implements payment {

        public void processPayment() {
            System.out.println("DONE");
        }

        public void generatePayment() {
            System.out.println("RECIEVED");

        }

    }

    class PayPalPayment implements payment
    object public {

    }

    fun eneratePayment(function: () -> Unit): Any {

    }

    {

        public void processPayment() {
            System.out.println("DONE");

        }

        public void eneratePayment() {
            System.out.println("RECIEVED");
        }
