public class Main {
    public static void main(String[] args) {

            Toolkit sc = new Toolkit();
            sc.calculate(1, 3);

            sc.calculate(12,3.1);
            sc.calculate(7.5,9.6);
        }
    }
