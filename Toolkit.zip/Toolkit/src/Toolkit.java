public class Toolkit {
    public void calculate(int a, int b) {
        int result = a + b;
        System.out.println("Result" + result);
        System.out.println("Maximum value=" + Math.max(a, b) + "Minimum value=" + Math.min(a, b));

    }

    public void calculate(int c, float d) {
        float result = c + d;
        System.out.println("Result is " + result);
        System.out.println("Maximum value=" + Math.max(c, d) + "Minimum value=" + Math.min(c, d));
    }

    public void calculate(double e,double f) {
        double result = e - f;
        System.out.println("Result is " + result);
        System.out.println("Maximum value=" + Math.max(e,f) + "Minimum value" + Math.min(e, f));
    }



}
